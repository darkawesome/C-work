﻿using System;

namespace HelloWorld
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");
            Console.WriteLine("This is my first line of code");

            var a = 40.0; //implicitly typed
            var b = 50.0;
            var c = a + b;
            var d = a / b;


            Console.WriteLine("{0} + {1} = {2}", a, b, c);
            Console.WriteLine("{0} / {1} = {2}", a, b, d);

            var f_name = "John";
            var l_name = "Doe";
            var full_name = f_name + "" + l_name;
            Console.WriteLine("My name is {0}", full_name);

            var datetime = DateTime.Now;
            Console.WriteLine(datetime);

            var date = datetime.Day;
            var time = datetime.TimeOfDay;
            Console.WriteLine("day : {0}; time: {1}", date, time);

            var user_input = "";
            user_input = Console.ReadLine();
            Console.WriteLine("You just entered {0}", user_input);
            //Console.Readkey();



        }
    }
}
